import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { WebsiteRoutingModule } from './website-routing.module';

import { AccountSharedModule } from '@account/shared/account-shared.module';
import { WebsiteComponent } from './home/website.component';

@NgModule({
    declarations: [WebsiteComponent],
    imports: [AppSharedModule, AccountSharedModule, WebsiteRoutingModule],
})
export class WebsiteModule {}
